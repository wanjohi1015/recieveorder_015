package com.blueprint.blueprintdeliv;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class Recview extends Fragment {
    RecyclerView recview;
    List<model> modelArrayList;
    Titlemodel chl;
    ArrayList<Titlemodel>  titleArrayList;
    FirebaseFirestore db;
    View vi;
    Titleadapter adapter;
    myadapter myadapter;
    String time;
    String timestamp;
    private model List;


    public Recview() {
        // Required empty public constructor
    }




    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup parent, @Nullable Bundle savedInstanceState) {


        // Inflate the layout for this fragment
        vi = inflater.inflate(R.layout.recview, parent, false);
        recview = vi.findViewById(R.id.recview);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        adapter = new Titleadapter(getActivity(), titleArrayList,modelArrayList);
        recview.setLayoutManager(layoutManager);
        recview.setAdapter(adapter);




        return vi;




    }


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        db = FirebaseFirestore.getInstance();
        modelArrayList = new ArrayList<>();
        titleArrayList = new ArrayList<>();


        db.collection("Orders").document("number").collection(List.getPhoneNumber())
                .whereEqualTo("number", List.getPhoneNumber())
                .orderBy("timestamp", Query.Direction.DESCENDING).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {


            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {

                    QuerySnapshot tasks = task.getResult();

                    assert tasks != null;
                    for (DocumentSnapshot dsp : tasks.getDocuments()) {

                        model mch = dsp.toObject(model.class);
                        chl = dsp.toObject(Titlemodel.class);
                        assert mch != null;
                        timestamp = mch.getTimestamp() + "";
                        modelArrayList.add(mch);
                        titleArrayList.add(chl);


                    }
                    adapter.notifyDataSetChanged();
                }
            }

        });


    }

    }

