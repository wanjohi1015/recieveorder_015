package com.blueprint.blueprintdeliv;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Titleadapter extends RecyclerView.Adapter<Titleadapter.titleviewholder>{

    private Activity activity;
    List<Titlemodel> titleArrayList;
    List<model> modelArrayList;
    myadapter myadapter;

    public Titleadapter(Activity activity, List<Titlemodel> titleArrayList, List<model> modelArrayList ){
    this.activity = activity;
    this.titleArrayList = titleArrayList;
    this.modelArrayList = modelArrayList;
    }


    @NonNull
    @Override
    public titleviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.title_item,parent,false);

        return new titleviewholder(view);
    }




    @Override
    public void onBindViewHolder(@NonNull Titleadapter.titleviewholder holder, int position) {

        Titlemodel titlemodell = titleArrayList.get(position);

        holder.number.setText(titlemodell.getPhoneNumber());
        holder.date.setText(titlemodell.getTimestamp()+"");

            myadapter = new myadapter(modelArrayList);
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(activity);
            holder.nested_rv.setLayoutManager(linearLayoutManager);
            holder.nested_rv.setAdapter(myadapter);

        myadapter.notifyDataSetChanged();



    }

    public class titleviewholder extends RecyclerView.ViewHolder {


        TextView number, date;
        RecyclerView nested_rv;

        public titleviewholder(@NonNull View itemView) {
            super(itemView);

            number = itemView.findViewById(R.id.number);
            date = itemView.findViewById(R.id.date);
            nested_rv = itemView.findViewById(R.id.nested_rv);

        }
    }



    @Override
    public int getItemCount() {
        return titleArrayList.size();
    }



}
