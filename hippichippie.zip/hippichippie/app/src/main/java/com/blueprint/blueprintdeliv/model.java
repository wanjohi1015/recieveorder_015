package com.blueprint.blueprintdeliv;

import com.google.firebase.firestore.ServerTimestamp;

import java.util.Date;

public class model {
    @ServerTimestamp Date timestamp;


    String  title, Phonenumber;
    int price, quantity;



    public model() {
    }

    public model(int price, int quantity, String title, String Phonenumber, Date timestamp) {
        this.price = price;
        this.quantity = quantity;
        this.title = title;
        this.Phonenumber = Phonenumber;
        this.timestamp = timestamp;

    }


    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }


    public String getPhoneNumber() {
        return Phonenumber;
    }

    public void setPhoneNumber(String Phonenumber) {
        this.Phonenumber = Phonenumber;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }
}


